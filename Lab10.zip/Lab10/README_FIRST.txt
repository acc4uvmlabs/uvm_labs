// // In this Lab, we practice use of DPI interface. 
// DPI is an acronym for Direct Programming Interface. 
// SV or UVM or OVM can import functions implemented in C in UVM testbench or export functions written in UVM in C-model. 
// It can be achieved using DPI interface. 
// To take benefit of templated files, you might want to preserve old files with different names
// New Files to work on: 
// 1. ./top/fifo_scoreboard.sv
// 2. ./sim/run 
// 3. ./package/fifo_pkg.sv 
// 4. ./c_code_base/fifo_model.c 

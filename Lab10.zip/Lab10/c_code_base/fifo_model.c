#include "svdpi.h" 
  void dpi_read_fn(){{
    printf("READ DPI FUNCTION FROM C-MODEL CALLED");
  }}
  // Write a similar function or user-defined function in C to be called in UVM testbench. 
  

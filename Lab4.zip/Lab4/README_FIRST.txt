// In this Lab, we will start building UVM hierarchy and also generate transactions for our RTL.  
// We are not building full UVM hierarchy. We didn't want to overwhelm you guys by making you do full UVM hierarchy in just 1 lab. ;) 
// Also, we wanted to break it into 10 labs, so we have to push it to make it till labs, right? ;) 
// We will do it step by step. 
// Files to work on: 
// 1. ./uvc/fifo_sequence_item.sv
// 2. ./uvc/fifo_sequencer.sv
// 3. ./uvc/fifo_driver.sv
// 4. ./uvc/fifo_monitor.sv
// 5. ./uvc/fifo_agent.sv
// 6. ./test/fifo_test.sv
// 7. ./package/fifo_pkg.sv 
// 8. ./top/fifo_top.sv 
//  
// WE ARE NOT DRIVING OUR RTL YET. HENCE WE DID NOT RTL FILE IN THIS LAB. 
// THE IDEA IS THAT WE WANT TO SHOW TO YOU THAT TESTBENCH BUILDING IS INDEPENDENT OF RTL BUILDING. 
// THEY ARE BOTH PARALLEL PROCESSES. 
//
// After you are done completing this lab, please take a moment in analyzing the simulation output. 
// What should you expect from your output? 
something like this 

UVM_INFO @ 0: reporter [UVMTOP] UVM testbench topology:
--------------------------------------------------------------------
Name                       Type                     Size  Value     
--------------------------------------------------------------------
uvm_test_top               fifo_base_test           -     @455      
  fifo_env                 fifo_env                 -     @463      
    fifo_agent             fifo_agent               -     @471      
      fifo_driver          fifo_driver              -     @492      
        rsp_port           uvm_analysis_port        -     @509      
        seq_item_port      uvm_seq_item_pull_port   -     @500      
      fifo_monitor         fifo_monitor             -     @484      
      fifo_sequencer       fifo_sequencer           -     @518      
        rsp_export         uvm_analysis_export      -     @526      
        seq_item_export    uvm_seq_item_pull_imp    -     @632      
        arbitration_queue  array                    0     -         
        lock_queue         array                    0     -         
        num_last_reqs      integral                 32    'd1       
        num_last_rsps      integral                 32    'd1       
      is_active            uvm_active_passive_enum  1     UVM_ACTIVE
--------------------------------------------------------------------

// What do you understand from this output: 
// fifo_base_test is the top most file in UVM hierarchy. 
// Followed by fifo_env and then agent
// Agent has 3 components driver, sequencer and monitor. And if you look closely, you'll notice driver, monitor and sequencer fit on the same
// column of this file. It means that they are on the same hierarchy level in UVM architecture. 
// Capisce?

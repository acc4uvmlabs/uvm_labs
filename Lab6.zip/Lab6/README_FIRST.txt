// In this lab we create full testbench hierarchy. with master and slave agents.  
// To save time, you may copy previous working Lab files and build/create slave agent or practice the entire lab to build more confidence :) 
// Files to work on :
// 1. ./uvc/fifo_slave_monitor.sv
// 2. ./uvc/fifo_slave_agent.sv
// 3. ./uvc/fifo_env.sv
// 4. ./top/fifo_tb.sv
// 5. ./test/fifo_test.sv
// 6. ./package/fifo_pkg.sv
// 7. ./uvc/fifo_uvc.svh
 
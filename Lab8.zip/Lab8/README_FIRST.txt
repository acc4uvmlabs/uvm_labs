// This lab is creating full testbench hierarchy. 
// To save time, you may copy previous working Lab 7 files and build/create scoreboard or practice the entire lab to build more confidence :) 
// To take benefit of templated files, you might want to preserve old files with different names
// New Files to work on: 
// 1. ./uvc/fifo_master_monitor.sv
// 2. ./uvc/fifo_slave_monitor.sv
// 3. ./top/fifo_scoreboard.sv
// 4. ./top/fifo_tb.sv
// 5. ./uvc/fifo_uvc.svh
// 